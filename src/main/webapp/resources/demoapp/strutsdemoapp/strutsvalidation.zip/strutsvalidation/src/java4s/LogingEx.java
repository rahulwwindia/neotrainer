package java4s;
import bean.Bean;

import com.opensymphony.xwork2.ActionSupport;
public class LogingEx extends ActionSupport{
    private static final long serialVersionUID = 1L;
 
    private Bean x ;
    
    public String execute()
    {        
  
            return SUCCESS;
 
    }

	public void setX(Bean x) {
		this.x = x;
	}
 
	public Bean getX() {
		return x;
	}

  
} 